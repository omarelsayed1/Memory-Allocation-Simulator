/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package os.pkg2.project;

/**
 *
 * @author Omar
 */
public class OS2Project {

    static void FirstFitAlgo(float SizeOfBlock[], float YM, int SizeOfProcess[], int XM)
    {
        int ProcessAllocation[] = new int[XM];
        for (int ip = 0; ip < ProcessAllocation.length; ip++)
            ProcessAllocation[ip] = -1;
        for (int ip = 0; ip < XM; ip++)
        {
        for (int jp = 0; jp < YM; jp++)
        {
        if (SizeOfBlock[jp] >= SizeOfProcess[ip])
        {
        ProcessAllocation[ip] = jp;
        SizeOfBlock[jp] -= SizeOfProcess[ip];
        break;
        }
        }
        }
     
        System.out.println("Process Number   Process Size    Block Number");
        for (int ip = 0; ip < XM; ip++)
        {
        System.out.print("      " + (ip+1) + "                " + SizeOfProcess[ip] + "            ");
        if (ProcessAllocation[ip] != -1)
        System.out.print(ProcessAllocation[ip] + 1);
        else
        System.out.print("Process Not Allocated");
        System.out.println();
        }
    }
    
    
    static void BestFitAlgo(int[] SizeOfBlock, int YM, int[] SizeOfProcess, int XM)
    {
        int[] ProcessAllocation = new int[XM];
        for (int ip = 0; ip < ProcessAllocation.length; ip++)
        ProcessAllocation[ip] = -1;
        for (int ip=0; ip<XM; ip++)
        {
        int BFit = -1;
        for (int jp=0; jp<YM; jp++)
        {
        if (SizeOfBlock[jp] >= SizeOfProcess[ip])
        {
        if (BFit == -1)
        BFit = jp;
        else if (SizeOfBlock[BFit] > SizeOfBlock[jp])
        BFit = jp;
        }
        }
        if (BFit != -1)
        {
        ProcessAllocation[ip] = BFit;
        SizeOfBlock[BFit] -= SizeOfProcess[ip];
        }
        }
        System.out.println("Process Number   Process Size    Block Number");
        for (int ip = 0; ip < XM; ip++)
        {
        System.out.print("      " + (ip+1) + "                " + SizeOfProcess[ip] + "            ");
        if (ProcessAllocation[ip] != -1)
        System.out.print(ProcessAllocation[ip] + 1);
        else
        System.out.print("Process Not Allocated");
        System.out.println();
        }
    }
    
    
    static void WorstFitAlgo(int[] SizeOfBlock, int YM, int[] SizeOfProcess,int XM)
    {
        int[] ProcessAllocation = new int[XM];
        for (int ip = 0; ip < ProcessAllocation.length; ip++)
        ProcessAllocation[ip] = -1;
        for (int i=0; i<XM; i++)
        {
        int WorstFit = -1;
        for (int jp=0; jp<YM; jp++)
        {
        if (SizeOfBlock[jp] >= SizeOfProcess[i])
        {
        if (WorstFit == -1)
        WorstFit = jp;
        else if (SizeOfBlock[WorstFit] < SizeOfBlock[jp])
        WorstFit = jp;
        }
        }
        if (WorstFit != -1)
        {
        ProcessAllocation[i] = WorstFit;
        SizeOfBlock[WorstFit] -= SizeOfProcess[i];
        }
        }
        System.out.println("Process Number   Process Size    Block Number");
        for (int ip = 0; ip < XM; ip++)
        {
        System.out.print("      " + (ip+1) + "                " + SizeOfProcess[ip] + "            ");
        if (ProcessAllocation[ip] != -1)
        System.out.print(ProcessAllocation[ip] + 1);
        else
        System.out.print("Process Not Allocated");
        System.out.println();
        }
    }
    public static void main(String[] args) {
        int SizeOfBlock[] = {4500, 3000, 1500, 2000, 7500};
        int SizeOfProcess[] = {3000, 2680, 2000, 1740};
        int YM = SizeOfBlock.length;
        int XM = SizeOfProcess.length;
        WorstFitAlgo(SizeOfBlock ,YM, SizeOfProcess, XM);
        
    }
    
}

